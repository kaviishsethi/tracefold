---
name: Tracefold
description: A precise editorial workbench for reviewing matching passages and local risks.
colors:
  paper: "#f7f6f2"
  surface: "#fffefa"
  nav: "#eeede7"
  ink: "#282b27"
  muted: "#5b6056"
  line: "#dcded4"
  accent: "#f2ce76"
  accent-soft: "#fff0c9"
  accent-ink: "#725016"
  green: "#375b48"
  green-soft: "#edf3ec"
  red: "#914b3e"
typography:
  display:
    fontFamily: "Newsreader, Georgia, serif"
    fontSize: "40px"
    fontWeight: 400
    lineHeight: 1.15
    letterSpacing: "-.025em"
  headline:
    fontFamily: "DM Sans, sans-serif"
    fontSize: "20px"
    fontWeight: 500
    lineHeight: 1.35
    letterSpacing: "normal"
  title:
    fontFamily: "DM Sans, sans-serif"
    fontSize: "15px"
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: "normal"
  body:
    fontFamily: "DM Sans, sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: "normal"
  label:
    fontFamily: "DM Sans, sans-serif"
    fontSize: "12px"
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: "normal"
  code:
    fontFamily: "ui-monospace, SFMono-Regular, Consolas, monospace"
    fontSize: "12px"
    fontWeight: 400
    lineHeight: 2
    letterSpacing: "normal"
rounded:
  small: "4px"
  field: "6px"
  standard: "8px"
  panel: "12px"
spacing:
  step-4: "4px"
  step-8: "8px"
  step-12: "12px"
  step-16: "16px"
  step-20: "20px"
  step-24: "24px"
  step-28: "28px"
  step-32: "32px"
  step-40: "40px"
  step-48: "48px"
components:
  button-primary:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.surface}"
    rounded: "{rounded.standard}"
    padding: "10px 16px"
  button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.standard}"
    padding: "10px 16px"
  button-text:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    padding: "10px 0"
  review-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.field}"
    padding: "12px"
  navigation-active:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.field}"
    padding: "12px"
  review-tag:
    backgroundColor: "{colors.accent-soft}"
    textColor: "{colors.accent-ink}"
    rounded: "{rounded.small}"
    padding: "4px 8px"
  evidence-panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
---
# Design System: Tracefold

## Overview

**Creative North Star: "The Annotated Evidence Folio"**

The annotated technical evidence folio becomes a precise, editorial, investigative workbench. Warm paper surfaces and ink typography keep the interface quiet while amber matching passages carry the visual emphasis. Restrained controls, thin dividers, and generous reading space support deliberate inspection.

This documents the current code-first HTML/CSS prototype, not final screen approval. The approved direction and scope cover scan setup, paired public evidence, and MCP fix/recheck. Interactions use synthetic Northwind Relay examples and session-only state; no backend is connected.

**Key Characteristics:**
- Warm paper and ink with amber passage matching.
- Editorial serif headings paired with compact sans-serif controls.
- Flat, bordered surfaces and readable metadata.
- Visible coverage and distinct observation and review states.

## Colors

Warm neutral surfaces, dark botanical ink, and muted amber evoke a technical folio with marked passages. The frontmatter preserves the implemented CSS values; descriptive names below explain their use.

### Primary
- **Passage Amber** (`accent`): selection and the match key.
- **Highlighted Paper** (`accent-soft`): matching text, review tags, and explanatory banners.
- **Annotation Ink** (`accent-ink`): amber-state text, caret, and visible focus outlines.

### Secondary
- **Verified Leaf** (`green`) and **Leaf Wash** (`green-soft`): bounded recheck outcomes, paired with explicit wording.
- **Error Clay** (`red`): form validation errors. Diff removals use a related clay treatment, additions a related green treatment.

### Neutral
- **Warm Paper** (`paper`): the workspace canvas.
- **Reading Sheet** (`surface`): evidence and inputs.
- **Folio Rail** (`nav`): navigation background.
- **Charcoal Ink** (`ink`): primary text and primary buttons.
- **Olive Gray** (`muted`): supporting text and line numbers; retain the current corrected value in frontmatter.
- **Paper Seam** (`line`): borders and dividers.

**The Evidence Emphasis Rule.** Reserve amber emphasis for matching passages and evidence-related states; keep primary controls in ink.

## Typography

**Display Font:** Newsreader, with Georgia and serif fallbacks.
**Body Font:** DM Sans, with sans-serif fallback.
**Label/Mono Font:** System monospace for code and tool names.

The serif establishes document-like hierarchy; sans-serif controls and metadata keep the workbench compact. Code retains a familiar fixed-width rhythm. Frontmatter carries base roles; evidence titles, document headings, and responsive variants refine those roles in the implementation.

### Hierarchy
- **Display:** page headings use the display role; step down to 36px at the middle breakpoint and 34px on phones.
- **Headline:** section headings use the headline role; evidence titles use 23px and phone evidence titles 21px.
- **Title:** compact section labels use the title role.
- **Body:** default body role; passage and descriptive text use 13px with passage line-height 1.8. Explanatory prose is typically bounded to 65–70ch.
- **Label:** metadata, timestamps, status, and table text use the label role. Use tabular numerals for counts and line numbers.
- **Code:** the code role supports readable diffs and horizontal scrolling when needed.

**The Readable Metadata Rule.** Keep visible metadata at 12px or larger, including narrow layouts.

## Layout

The desktop shell uses a 216px workspace rail, 72px top bar, and 40px main padding. The evidence workbench combines a 248px finding index with a flexible detail pane and paired equal-width documents. Setup and recheck use task content with narrower summary/history columns. Repeated spacing follows the extracted four-pixel rhythm.

At 1200px and below, the rail becomes 188px, main padding becomes 32px 24px, and the finding index becomes 212px. At 980px and below, the rail becomes 168px, findings form a two-column strip, and setup/recheck collapse to one content column. At 700px and below, navigation moves above the content, main padding becomes 28px 20px, passages stack private before public, and actions wrap or fill the available width. Tables and code can scroll. At 1600px and above, main content is capped at 1440px. These are implemented responsive rules, not claims of completed visual QA.

## Elevation & Depth

Surfaces are flat: tonal changes and one-pixel borders establish grouping. There are no elevated panel or button shadows. Timeline markers use a paper-colored halo to clear the connecting line; this is a separator, not elevation.

**The Flat Surface Rule.** Separate surfaces with tone and thin borders, not decorative elevation.

## Shapes

Small tags use the small radius; inputs and navigation use the field radius; buttons and paired passages use the standard radius; the workbench and recheck panel use the panel radius. Circular status dots and timeline markers are compact signals accompanied by text. Borders are thin, corners restrained, and evidence remains rectangular.

## Components

### Buttons
Quiet, clearly actionable controls. Primary buttons use ink on reading-sheet text; secondary buttons are transparent with a light border; text buttons are underlined. Buttons have a minimum 44px height. Primary hover uses a lighter ink (#43483e); secondary hover uses a pale neutral (#eaece3). Background and border transitions last 160ms with ease-out. Focus is an annotation-ink 2px outline with 4px offset. Disabled buttons reduce opacity and show an unavailable cursor.

### Chips
Review tags use highlighted paper and annotation ink with small corners. Status labels pair a small colored dot with written meaning. They are informative labels, not substitute controls.

### Cards / Containers
Panels group substantive evidence, not decorative summaries. Reading-sheet surfaces, paper-seam borders, restrained corners, and 20–28px detail padding support comparison. The paired passage container has a shared border and internal divider; phone layouts move that divider between stacked passages.

### Inputs / Fields
Review fields use reading-sheet backgrounds, a muted stroke, field corners, and 12px padding. Textareas resize vertically. Focus shares the global outline. Errors use error clay plus explicit text. Source/check selections use native checkboxes inside larger clickable labels. The upload zone uses a dashed border, becomes amber on hover/drag, and shows an outline when its adjacent file input has keyboard-visible focus.

### Navigation
The muted rail uses 44px-minimum links with small icons and compact labels. The current page has a reading-sheet fill and ink text; hover uses a slightly darker rail tone. On phones the links form a horizontal strip. Evidence tabs have an ink underline for selection, visible focus, and Arrow/Home/End keyboard navigation.

### Paired evidence and recheck
The signature comparison aligns labeled private and public passages, highlighted matching text, line numbers, and bounded match metadata. Coverage and history are sibling tabs. Review decisions remain separate from scanner observations. Recheck shows a red/green code diff with explicit minus/plus markers, a version timeline, and a separate still-open public exposure. Simulated progress uses a one-second ease-out line; reduced-motion disables animation and transitions. File selection stores names only, and review notes remain in memory for this prototype session.

## Do's and Don'ts

### Do:
- **Do** preserve paired passage context, line numbers, and explicit source labels.
- **Do** keep metadata at least 12px and primary control targets at least 44px.
- **Do** show keyboard focus and honor reduced-motion preferences.
- **Do** keep failed or unknown coverage legible beside findings.
- **Do** label simulated operations and sample content.

### Don't:
- **Don't** turn a local recheck into a visual all-clear for a separate public exposure.
- **Don't** replace the evidence workbench with generic nested card grids.
- **Don't** use color alone to communicate a status.
- **Don't** present prototype controls or planned connectors as live services.
